"""
Acceso al estado online de SIGEA (estado.json publicado vía GitHub/Railway).

Nota histórica (v2.1.4): hasta el Sprint 1 este módulo era un cliente HTTP
del servidor Flask LAN (localhost:5000), eliminado porque Trellix bloquea
esa vía en máquinas SERVEL. Las funciones de esa época (ping, avance,
entregar, cargar_gpkg) quedaron sin llamadas y se eliminaron. La única
fuente de datos del plugin es estado_online().
"""
import json
from urllib import request

from . import settings


class SigeaError(Exception):
    pass


def estado_online():
    """Lee el estado.json publicado y devuelve la asignación del usuario
    actual: (asig_dict_o_None, generado). Lanza SigeaError si no hay URL o
    no se puede leer."""
    url = settings.estado_url()
    if not url:
        raise SigeaError("Sin URL de estado online configurada.")
    if not url.endswith(".json"):
        url = url + "/estado.json"
    try:
        with request.urlopen(url, timeout=8) as r:
            data = json.loads(r.read().decode())
    except Exception as e:
        raise SigeaError(f"No se pudo leer el estado online: {e}")

    asig = (data.get("funcionarios") or {}).get(settings.usuario())

    if asig is not None:
        # Normalizar al formato que espera el panel
        asig.setdefault("id", asig.get("asignacion_id"))
        asig.setdefault("unidad_nombre", asig.get("unidad"))
        asig.setdefault("avance", asig.get("avance", 0))
        # Normalizar cada asignación de la lista (si viene)
        for a in asig.get("asignaciones", []):
            a.setdefault("id", a.get("asignacion_id"))
            a.setdefault("unidad_nombre", a.get("unidad"))
    return asig, data.get("generado", "")
