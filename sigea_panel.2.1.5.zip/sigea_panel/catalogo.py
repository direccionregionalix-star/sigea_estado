"""
catalogo.py — Genera y publica recintos_catalogo.json (Fase 1, diseño Seba).

El dashboard no puede leer central.gpkg (el navegador no toca archivos).
Este módulo genera un catálogo LIVIANO de los recintos del central y lo
publica a la raíz del repo GitHub con el mismo mecanismo de escritura que
ya usa el plugin (_r/_t vía github_report). Con él, el dashboard construye
la vista de decisión para asignar (282 filas de texto).

REGLA NO SE TOCA — datos sensibles: el catálogo lleva SOLO
codigo, nombre, comuna y n_electores por recinto. Nombres de recintos y
comunas son información pública. JAMÁS datos de electores (ni conteos por
tipo geo ni nada derivado del padrón individual).

Publicación:
  - Botón "Publicar catálogo" en el modo admin (manual).
  - Refresco automático best-effort al abrir el modo admin si el catálogo
    publicado tiene más de MAX_DIAS_CATALOGO días (o no existe). Nunca
    bloquea ni rompe la apertura del diálogo.
"""
import json
from datetime import datetime, timezone

from . import github_report

_RUTA_CATALOGO = "recintos_catalogo.json"
MAX_DIAS_CATALOGO = 3

# Campos permitidos en el catálogo. Cualquier otro campo se descarta:
# es la barrera explícita contra fugas de datos sensibles.
_CAMPOS_PERMITIDOS = ("codigo", "nombre", "comuna", "n_electores")


def generar_catalogo():
    """Lee central.gpkg (vía admin_archivos.listar_recintos_central) y arma
    el dict del catálogo. Devuelve (catalogo_dict, error_msg)."""
    from . import admin_archivos
    recintos, err = admin_archivos.listar_recintos_central(estado=None)
    if err:
        return None, err
    if not recintos:
        return None, "El central no devolvió recintos."

    filas = []
    for r in sorted(recintos, key=lambda x: x.get("codigo", "")):
        filas.append({k: r.get(k) for k in _CAMPOS_PERMITIDOS})

    return {
        "generado": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "n_recintos": len(filas),
        "recintos": filas,
    }, None


def antiguedad_dias():
    """Edad en días del catálogo publicado en GitHub, o None si no existe
    o no se puede leer. No lanza excepciones."""
    try:
        creds = github_report._obtener_credenciales()
        from .bitacora import _github_get_raw
        contenido, _sha = _github_get_raw(
            creds["repo"], creds["branch"], _RUTA_CATALOGO, creds["token"])
        gen = contenido.get("generado")
        if not gen:
            return None
        # _github_get_raw devuelve {"eventos": []} para 404 → sin "generado"
        t = datetime.fromisoformat(str(gen).replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - t).total_seconds() / 86400.0
    except Exception:
        return None


def publicar_catalogo():
    """Genera el catálogo desde el central y lo publica a GitHub.
    Devuelve (ok, msg)."""
    catalogo, err = generar_catalogo()
    if err:
        return False, f"No se pudo generar el catálogo: {err}"

    try:
        creds = github_report._obtener_credenciales()
    except RuntimeError as e:
        return False, f"Sin credenciales para publicar: {e}"

    try:
        contenido = json.dumps(catalogo, ensure_ascii=False, indent=1)
        github_report._github_put(
            creds["repo"], creds["branch"], _RUTA_CATALOGO, contenido,
            creds["token"],
            f"catalogo recintos ({catalogo['n_recintos']})")
        return True, (f"Catálogo publicado: {catalogo['n_recintos']} recintos "
                      f"(recintos_catalogo.json).")
    except Exception as e:
        return False, f"Error publicando el catálogo: {e}"


def refrescar_si_viejo(max_dias=MAX_DIAS_CATALOGO):
    """Publica el catálogo solo si el publicado no existe o tiene más de
    max_dias. Best-effort: devuelve (accion, msg) con accion en
    {'publicado', 'vigente', 'error'}. Nunca lanza."""
    try:
        edad = antiguedad_dias()
        if edad is not None and edad <= max_dias:
            return "vigente", f"Catálogo vigente ({edad:.1f} días)."
        ok, msg = publicar_catalogo()
        return ("publicado" if ok else "error"), msg
    except Exception as e:
        return "error", str(e)
