"""
Comunas — resolución del código SII de 4 dígitos que pide SIGEC, a partir de
lo que traiga la capa de trabajo (código CUT, código SII o nombre).

El código SIGEC (4 dígitos, ej. "9115" Pucón) coincide con el código CUT sin
el cero a la izquierda. Si la capa trae el nombre, se invierte el mapa.

La TABLA de comunas es dato regional: vive en region_config.COMUNAS (único
punto que se cambia por región). Este módulo solo aporta la lógica de
resolución, que es la misma para cualquier región.
"""
from .region_config import COMUNAS


def _normalizar_texto(s):
    """minúsculas, sin tildes, sin espacios extra — para comparar nombres."""
    if s is None:
        return ""
    s = str(s).strip().lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u"),
                 ("ñ", "n")):
        s = s.replace(a, b)
    return " ".join(s.split())


# Mapa inverso nombre normalizado → código
_POR_NOMBRE = {_normalizar_texto(v): k for k, v in COMUNAS.items()}


def codigo_sigec(valor):
    """Resuelve el código SII de 4 dígitos que pide SIGEC desde lo que sea
    que traiga la capa: código CUT ('09115'), código SII ('9115'), float
    ('9115.0') o nombre ('Pucón'). Devuelve el código o None si no se puede."""
    if valor is None:
        return None
    bruto = str(valor).strip()
    if not bruto:
        return None

    # ¿Es numérico (código)? Quitar parte decimal y ceros a la izquierda
    candidato = bruto.split(".")[0].lstrip("0")
    if candidato.isdigit():
        # Código SII de la región = 4 dígitos presentes en COMUNAS
        if candidato in COMUNAS:
            return candidato
        # A veces viene el código de 5 dígitos sin cero (raro) o con región
        if len(candidato) == 5 and candidato[0] == "0":
            c2 = candidato.lstrip("0")
            if c2 in COMUNAS:
                return c2

    # ¿Es nombre?
    cod = _POR_NOMBRE.get(_normalizar_texto(bruto))
    if cod:
        return cod

    return None


def nombre_de(codigo):
    """Nombre de comuna desde su código SII de 4 dígitos o CUT de 5
    dígitos con cero inicial ("09121" → Cholchol). Si el valor no es un
    código conocido (p. ej. ya viene el nombre), lo devuelve tal cual."""
    s = str(codigo).strip()
    return COMUNAS.get(s) or COMUNAS.get(s.lstrip("0")) or s


def opciones_ordenadas():
    """Lista [(codigo, nombre)] ordenada por nombre, para poblar un combo."""
    return sorted(COMUNAS.items(), key=lambda kv: kv[1])
