"""
region_config.py — Configuración específica de la REGIÓN (plugin QGIS).

═══════════════════════════════════════════════════════════════════════════
PUNTO ÚNICO de todo lo que cambia al levantar el sistema en otra región.
Los valores por defecto son los de La Araucanía. Para una región nueva
(ej. Los Ríos) se levanta una instancia INDEPENDIENTE con su propio repo y
Railway, y se completa ESTE archivo con sus valores — nada más del código
debería tener datos regionales hardcodeados.

Ver docs/GUIA_NUEVA_REGION.md para el procedimiento completo.
═══════════════════════════════════════════════════════════════════════════

Clasificación (ver docs/PORTABILIDAD_REGIONAL.md):
  - DATO      : cambia según la región (tabla de comunas).
  - IDENTIDAD : nombre/marca/servicios propios de la región (título, SIGEC,
                clave de ofuscación).
Lo UNIVERSAL (dominios de tipo geo de SERVEL, nombres de campos) NO vive
aquí: es igual en todas las regiones y se queda en su lugar.
"""

# ─── IDENTIDAD ──────────────────────────────────────────────────────────────

# Nombre de la región (para textos de UI y firmas).
REGION_NOMBRE = "La Araucanía"

# Firma institucional que va al pie de los correos y en textos del plugin.
REGION_FIRMA = "SIGEA DR Araucanía"


# ─── DATO: tabla de comunas ────────────────────────────────────────────────
# Código SII/CUT de 4 dígitos → nombre. Para Araucanía son 91xx/92xx (región
# IX). Otra región cambia TODA esta tabla por la suya (ej. Los Ríos = 14xx).
COMUNAS = {
    "9101": "Temuco", "9102": "Carahue", "9103": "Cunco",
    "9104": "Curarrehue", "9105": "Freire", "9106": "Galvarino",
    "9107": "Gorbea", "9108": "Lautaro", "9109": "Loncoche",
    "9110": "Melipeuco", "9111": "Nueva Imperial", "9112": "Padre Las Casas",
    "9113": "Perquenco", "9114": "Pitrufquén", "9115": "Pucón",
    "9116": "Saavedra", "9117": "Teodoro Schmidt", "9118": "Toltén",
    "9119": "Vilcún", "9120": "Villarrica", "9121": "Cholchol",
    "9201": "Angol", "9202": "Collipulli", "9203": "Curacautín",
    "9204": "Ercilla", "9205": "Lonquimay", "9206": "Los Sauces",
    "9207": "Lumaco", "9208": "Purén", "9209": "Renaico",
    "9210": "Traiguén", "9211": "Victoria",
}


# ─── IDENTIDAD: servicio SIGEC (geocodificador de predios, Supabase) ────────
# Cada región tiene su propio proyecto SIGEC/Supabase. Read-only vía anon key
# (RLS), segura de embeber. Vacío = el buscador SIGEC queda inactivo.
SIGEC_BASE = "https://cbqpeusznwotoeftkegw.supabase.co"
SIGEC_ANON = "sb_publishable_jp4zBRi9mDjZREBckfkyIA_kZ0dcHon"


# ─── IDENTIDAD/SECRETO: clave de ofuscación del token de escritura ──────────
# XOR sobre el token "_t" del estado.json. DEBE coincidir con la del dashboard
# (index.html deofuscar) y la del servidor (server.js deofuscar). Para una
# región nueva conviene una clave propia — cámbiala en LOS TRES lugares.
OFUSCACION_KEY = b"SIGEA2026araucania"
