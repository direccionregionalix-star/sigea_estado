"""
SIGEA Panel — Widget principal v1.1
- Detección de capa ya cargada (no duplica)
- Conteos por tipo_geo en cada botón
- Modo desconectado (lee gpkg local sin SIGEA)
- Tipos ocultables desde opciones avanzadas
"""
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QFrame, QScrollArea, QTextEdit, QDialog,
    QDialogButtonBox, QCheckBox, QMessageBox, QGroupBox,
    QSpacerItem, QSizePolicy
)
from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QColor

from qgis.core import QgsProject, QgsVectorLayer

from . import api, settings, rutas

import os as _os
import json as _json
import hashlib as _hashlib
from datetime import datetime as _dt

_MANIFEST_SUFIJO = ".listo"


def _manifest_hash(ruta, bloque=1 << 20):
    h = _hashlib.sha256()
    with open(ruta, "rb") as fh:
        while True:
            b = fh.read(bloque)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _manifest_escribir(ruta, por="Plugin QGIS"):
    """Escribe el manifest .listo tras guardar el gpkg (verificación OneDrive)."""
    try:
        datos = {"archivo": _os.path.basename(ruta),
                 "bytes": _os.path.getsize(ruta),
                 "sha256": _manifest_hash(ruta),
                 "generado": _dt.now().isoformat(timespec="seconds"),
                 "por": por}
        tmp = ruta + _MANIFEST_SUFIJO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            _json.dump(datos, fh, ensure_ascii=False, indent=1)
        _os.replace(tmp, ruta + _MANIFEST_SUFIJO)
        return True
    except Exception:
        return False


def _manifest_verificar(ruta):
    """Devuelve (estado, detalle): ok | sincronizando | sin_manifest | sin_archivo."""
    if not _os.path.exists(ruta):
        return "sin_archivo", "El archivo aún no llega a tu OneDrive."
    rm = ruta + _MANIFEST_SUFIJO
    if not _os.path.exists(rm):
        return "sin_manifest", ""
    try:
        with open(rm, encoding="utf-8") as fh:
            m = _json.load(fh)
    except Exception:
        return "sincronizando", "Manifest ilegible (sincronizando)."
    try:
        if _os.path.getmtime(ruta) > _os.path.getmtime(rm) + 2:
            return "sin_manifest", ""  # archivo editado después: no verificable
    except OSError:
        pass
    if _os.path.getsize(ruta) != m.get("bytes"):
        return "sincronizando", "OneDrive aún está bajando este archivo."
    if _manifest_hash(ruta) != m.get("sha256"):
        return "sincronizando", "OneDrive aún está bajando este archivo."
    return "ok", ""

# ---------------------------------------------------------------------------
# Dominio tipo_geo_id
# ---------------------------------------------------------------------------
TIPOS_GEO = [
    (2,  "EXACTO",         "#2e7d32"),
    (1,  "LOCALIDAD",      "#558b2f"),
    (3,  "CALLE",          "#f9a825"),
    (5,  "PROXIMIDAD",     "#ef6c00"),
    (4,  "NO GEO",         "#c62828"),
    (6,  "FUERA COMUNA",   "#6a1b9a"),
    (7,  "AUTOGEO",        "#0277bd"),
    (8,  "RECINTO NO GEO", "#546e7a"),
    (9,  "SIN TIPO",       "#757575"),
    (10, "MASIVO",         "#00838f"),
]
CAMPO_TIPO_GEO = "tipo_geo_id"
MAPA_TIPOS = {c: t for c, t, _ in TIPOS_GEO}


def _sep():
    f = QFrame(); f.setFrameShape(QFrame.HLine)
    f.setStyleSheet("color: #e0e0e0;"); return f


def _lbl_sec(txt):
    l = QLabel(txt)
    l.setStyleSheet("font-size:10px;font-weight:600;color:#888;"
                    "text-transform:uppercase;letter-spacing:1px;"
                    "margin-top:6px;margin-bottom:2px;")
    return l


class SigeaPanel(QWidget):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.asignacion = None
        self.capa_activa = None
        self._codigo_activo = None
        self._conectado = False
        self._modo = "cache"
        self._build_ui()
        self._setup_timer()
        self.cargar_asignacion()

    # ------------------------------------------------------------------
    # Construcción UI
    # ------------------------------------------------------------------
    def _build_ui(self):
        self.setMinimumWidth(240)
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(3)

        # Cabecera
        self._lbl_usuario = QLabel("—")
        self._lbl_usuario.setStyleSheet(
            "font-size:13px;font-weight:700;color:#1a1a2e;")
        self._lbl_estado = QLabel("● Desconectado")
        self._lbl_estado.setStyleSheet("font-size:11px;color:#999;")

        hdr = QHBoxLayout()
        izq = QVBoxLayout()
        izq.setSpacing(1)
        izq.addWidget(self._lbl_usuario)
        izq.addWidget(self._lbl_estado)
        hdr.addLayout(izq); hdr.addStretch()

        self._btn_refresh = QPushButton("↻")
        self._btn_refresh.setFixedSize(26, 26)
        self._btn_refresh.setToolTip("Recargar asignación desde SIGEA")
        self._btn_refresh.setStyleSheet(
            "QPushButton{border:1px solid #ccc;border-radius:4px;font-size:13px;}"
            "QPushButton:hover{background:#f0f0f0;}")
        self._btn_refresh.clicked.connect(self.cargar_asignacion)
        hdr.addWidget(self._btn_refresh)

        self._btn_config = QPushButton("⚙")
        self._btn_config.setFixedSize(26, 26)
        self._btn_config.setToolTip("Configuración: URL, usuario y carpeta de trabajo")
        self._btn_config.setStyleSheet(
            "QPushButton{border:1px solid #ccc;border-radius:4px;font-size:13px;}"
            "QPushButton:hover{background:#f0f0f0;}")
        self._btn_config.clicked.connect(self._abrir_config)
        hdr.addWidget(self._btn_config)
        root.addLayout(hdr)
        root.addWidget(_sep())

        # Recinto activo
        root.addWidget(_lbl_sec("Mi recinto activo"))
        self._lbl_recinto = QLabel("Sin asignación activa")
        self._lbl_recinto.setStyleSheet(
            "font-size:14px;font-weight:700;color:#1a1a2e;")
        self._lbl_recinto.setWordWrap(True)
        root.addWidget(self._lbl_recinto)

        self._lbl_meta = QLabel("")
        self._lbl_meta.setStyleSheet("font-size:11px;color:#555;")
        root.addWidget(self._lbl_meta)

        self._lbl_plazo = QLabel("")
        self._lbl_plazo.setStyleSheet("font-size:11px;")
        root.addWidget(self._lbl_plazo)

        self._progress = QProgressBar()
        self._progress.setRange(0, 100)
        self._progress.setValue(0)
        self._progress.setFixedHeight(13)
        self._progress.setStyleSheet(
            "QProgressBar{border:1px solid #ccc;border-radius:3px;"
            "background:#eee;text-align:center;font-size:10px;}"
            "QProgressBar::chunk{background:#2e7d32;border-radius:2px;}")
        root.addWidget(self._progress)

        self._lbl_avance = QLabel("0 / 0 rectificados")
        self._lbl_avance.setStyleSheet("font-size:11px;color:#555;")
        root.addWidget(self._lbl_avance)

        self._btn_cargar = QPushButton("▶  Cargar recinto en mapa")
        self._btn_cargar.setStyleSheet(self._estilo("#1565c0", "#1976d2"))
        self._btn_cargar.clicked.connect(self.cargar_capa)
        self._btn_cargar.setEnabled(False)
        root.addWidget(self._btn_cargar)

        root.addWidget(_sep())

        # Botonera tipo_geo
        root.addWidget(_lbl_sec("Asignar tipo geo  (puntos seleccionados)"))

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        cont = QWidget()
        self._grid_tipos = QVBoxLayout(cont)
        self._grid_tipos.setContentsMargins(0, 0, 0, 0)
        self._grid_tipos.setSpacing(2)

        self._btns_tipo = {}
        ocultos = settings.tipos_ocultos()
        for codigo, texto, color in TIPOS_GEO:
            btn = self._crear_btn_tipo(codigo, texto, color)
            btn.setVisible(codigo not in ocultos)
            self._grid_tipos.addWidget(btn)
            self._btns_tipo[codigo] = btn

        scroll.setWidget(cont)
        scroll.setMaximumHeight(260)
        root.addWidget(scroll)

        root.addWidget(_sep())

        # Acciones
        root.addWidget(_lbl_sec("Acciones"))

        self._btn_avance = QPushButton("↑  Registrar avance en SIGEA")
        self._btn_avance.setStyleSheet(self._estilo("#546e7a", "#607d8b"))
        self._btn_avance.clicked.connect(self.registrar_avance)
        self._btn_avance.setEnabled(False)
        root.addWidget(self._btn_avance)

        self._btn_entregar = QPushButton("✓  Entregar recinto")
        self._btn_entregar.setStyleSheet(self._estilo("#2e7d32", "#388e3c"))
        self._btn_entregar.clicked.connect(self.entregar)
        self._btn_entregar.setEnabled(False)
        root.addWidget(self._btn_entregar)

        root.addStretch()

        self._lbl_msg = QLabel("")
        self._lbl_msg.setWordWrap(True)
        self._lbl_msg.setStyleSheet("font-size:10px;color:#555;margin-top:2px;")
        root.addWidget(self._lbl_msg)

    def _crear_btn_tipo(self, codigo, texto, color):
        btn = QPushButton()
        btn.setFixedHeight(30)
        btn.setStyleSheet(
            f"QPushButton{{background:{color};color:white;border:none;"
            f"border-radius:4px;font-size:11px;font-weight:600;"
            f"text-align:left;padding-left:8px;}}"
            f"QPushButton:hover{{filter:brightness(1.1);}}"
            f"QPushButton:disabled{{background:#ccc;color:#888;}}")
        btn.setEnabled(False)
        btn.setProperty("tipo_codigo", codigo)
        btn.clicked.connect(lambda _, c=codigo: self.asignar_tipo_geo(c))
        # Texto inicial sin conteo
        btn.setText(f"{texto}")
        return btn

    def _estilo(self, c, h):
        return (f"QPushButton{{background:{c};color:white;border:none;"
                f"border-radius:4px;padding:5px;font-size:11px;font-weight:600;}}"
                f"QPushButton:hover{{background:{h};}}"
                f"QPushButton:disabled{{background:#ccc;color:#888;}}")

    # ------------------------------------------------------------------
    # Timer
    # ------------------------------------------------------------------
    def _setup_timer(self):
        self._timer = QTimer(self)
        self._timer.setInterval(60_000)
        self._timer.timeout.connect(self._refrescar_silencioso)
        self._timer.start()

    # ------------------------------------------------------------------
    # Lógica principal
    # ------------------------------------------------------------------
    def cargar_asignacion(self):
        """Cadena de fallback: SIGEA (LAN) → estado online (Netlify) → caché.
        En LAN se puede todo; en online/caché solo rectificar localmente."""
        usuario = settings.usuario()
        self._lbl_usuario.setText(usuario or "Sin usuario")

        # 1) SIGEA en la LAN
        try:
            api.ping()
            self._set_modo("lan")
            asig = api.asignacion_activa(usuario)
            if not asig or asig.get("error"):
                self._set_sin_asignacion()
                return
            self._aplicar_asignacion(asig)
            return
        except api.SigeaError:
            pass

        # 2) Estado online (Netlify)
        try:
            asig, generado = api.estado_online()
            self._set_modo("online", generado)
            if asig is None:
                self._set_sin_asignacion()
                return
            self._aplicar_asignacion(asig)
            self._set_msg("Trabajando con el estado online. Para entregar, "
                          "coordina por Teams.", error=False)
            return
        except api.SigeaError:
            pass

        # 3) Caché local
        self._set_modo("cache")
        self._modo_desconectado()

    def _set_modo(self, modo, generado=""):
        """Modo de operación: lan | online | cache."""
        self._modo = modo
        self._conectado = (modo == "lan")
        if modo == "lan":
            self._lbl_estado.setText("● Conectado a SIGEA")
            self._lbl_estado.setStyleSheet("font-size:11px;color:#2e7d32;")
        elif modo == "online":
            hora = generado.replace("T", " ")[:16] if generado else "?"
            self._lbl_estado.setText(f"● Estado online (al {hora})")
            self._lbl_estado.setStyleSheet("font-size:11px;color:#0277bd;")
        else:
            self._lbl_estado.setText("● Sin conexión  (caché local)")
            self._lbl_estado.setStyleSheet("font-size:11px;color:#ef6c00;")

    def _aplicar_asignacion(self, asig):
        self.asignacion = asig
        # Fijar el código del recinto activo (blinda el conteo)
        self._codigo_activo = asig.get("codigo")
        # Cachear código + ruta LOCAL para modo desconectado
        try:
            cod = asig.get("codigo", "")
            ruta_local = rutas.ruta_gpkg(cod) if cod else None
            if ruta_local:
                settings.set_gpkg_path_cache(ruta_local, cod)
        except Exception:
            pass
        self._actualizar_vista()
        if self._modo == "lan":
            self._set_msg("")

    def _abrir_config(self):
        from .config_dialog import SigeaConfigDialog
        dlg = SigeaConfigDialog(self)
        if dlg.exec_():
            self._aplicar_tipos_ocultos()
            self.cargar_asignacion()

    def _aplicar_tipos_ocultos(self):
        ocultos = settings.tipos_ocultos()
        for codigo, btn in self._btns_tipo.items():
            btn.setVisible(codigo not in ocultos)

    def _modo_desconectado(self):
        """Carga desde caché local sin SIGEA."""
        gpkg_path = settings.gpkg_path_cache()
        codigo = settings.gpkg_codigo_cache()
        if not gpkg_path or not codigo:
            self._lbl_recinto.setText("Sin conexión y sin caché local.")
            self._lbl_meta.setText("Configura la conexión a SIGEA.")
            return

        self._codigo_activo = codigo
        self._lbl_recinto.setText(f"R{codigo}  (modo local)")
        self._lbl_meta.setText("Sin conexión a SIGEA — solo rectificación local")
        self._lbl_plazo.setText("")
        self._btn_cargar.setEnabled(True)
        # En modo desconectado no se puede registrar ni entregar
        self._btn_avance.setEnabled(False)
        self._btn_entregar.setEnabled(False)
        self._set_msg("Sin conexión a SIGEA. Puedes rectificar pero no registrar avance ni entregar.", error=True)

    def _set_sin_asignacion(self):
        self.asignacion = None
        self._lbl_recinto.setText("Sin asignación activa")
        self._lbl_meta.setText("")
        self._lbl_plazo.setText("")
        self._progress.setValue(0)
        self._lbl_avance.setText("0 / 0 rectificados")
        self._btn_cargar.setEnabled(False)
        self._btn_avance.setEnabled(False)
        self._btn_entregar.setEnabled(False)
        self._set_btns_tipo(False)

    def _actualizar_vista(self):
        a = self.asignacion
        self._lbl_recinto.setText(a.get("unidad_nombre", "—"))
        self._lbl_meta.setText(
            f"{str(a.get('comuna','')).title()} · {a.get('n_electores',0)} electores")

        dias = a.get("dias_restantes")
        if dias is None:
            txt, color = f"Plazo: {a.get('fecha_estimada','—')}", "#555"
        elif dias < 0:
            txt, color = f"⚠ Vencido hace {abs(dias)} días", "#c62828"
        elif dias <= 2:
            txt, color = f"⚠ {a.get('fecha_estimada')} ({dias} d)", "#ef6c00"
        else:
            txt, color = f"Plazo: {a.get('fecha_estimada')} ({dias} d)", "#2e7d32"
        self._lbl_plazo.setText(txt)
        self._lbl_plazo.setStyleSheet(
            f"font-size:11px;color:{color};font-weight:600;")

        rev = a.get("avance", 0)
        total = a.get("n_electores", 0)
        pct = round(100 * rev / total) if total else 0
        self._progress.setValue(pct)
        self._lbl_avance.setText(f"{rev} / {total} rectificados ({pct}%)")

        self._btn_cargar.setEnabled(True)
        es_lan = getattr(self, "_modo", "lan") == "lan"
        self._btn_avance.setEnabled(es_lan)
        self._btn_entregar.setEnabled(es_lan)
        tip = "" if es_lan else "Disponible solo conectado a SIGEA (en la oficina). Coordina por Teams."
        self._btn_avance.setToolTip(tip or "Registrar avance en SIGEA")
        self._btn_entregar.setToolTip(tip or "Entregar el recinto")

    # ------------------------------------------------------------------
    # Cargar capa — detecta si ya está cargada
    # ------------------------------------------------------------------
    def cargar_capa(self):
        # El código del recinto viene de SIGEA (o de la caché). La RUTA, en
        # cambio, la resolvemos localmente: la ruta absoluta de SIGEA no sirve
        # porque cada PC ve el OneDrive compartido con otro nombre.
        if self._conectado and self.asignacion:
            try:
                info = api.cargar_gpkg(self.asignacion["id"])
                codigo = info.get("codigo")
            except api.SigeaError as e:
                self._set_msg(f"Error: {e}", error=True); return
        else:
            codigo = settings.gpkg_codigo_cache()

        if not codigo:
            self._set_msg("No hay recinto asignado.", error=True)
            return

        # Ruta LOCAL en este PC
        ruta = rutas.ruta_gpkg(codigo)
        if not ruta:
            self._set_msg("No encuentro tu carpeta de trabajo. Ábrela con el "
                          "botón ⚙ y usa 'Examinar carpeta'.", error=True)
            return

        # Guardar el código activo: el conteo SIEMPRE será sobre esta capa
        self._codigo_activo = codigo
        # Cachear para modo desconectado
        settings.set_gpkg_path_cache(ruta, codigo)

        # Verificación de sincronización OneDrive antes de abrir
        est, det = _manifest_verificar(ruta)
        if est == "sin_archivo":
            self._set_msg(f"⏳ {det} (busqué en {ruta}). Si el archivo ya está "
                          "en tu OneDrive, revisa tu carpeta con el botón ⚙.",
                          error=True)
            return
        if est == "sincronizando":
            self._set_msg(f"⏳ {det} Reintenta en unos segundos.", error=True)
            return

        nombre_capa = f"R{codigo}"

        # Detectar si la capa ya está cargada en QGIS (por nombre Y ruta)
        for layer in QgsProject.instance().mapLayers().values():
            if (isinstance(layer, QgsVectorLayer) and
                    layer.name() == nombre_capa and layer.isValid() and
                    layer.source().split("|")[0] == ruta):
                self.capa_activa = layer
                self.iface.setActiveLayer(layer)
                self._set_msg(f"Capa {nombre_capa} ya estaba cargada — activada.")
                self._set_btns_tipo(True)
                try:
                    layer.selectionChanged.connect(self._on_sel_cambiada)
                except Exception:
                    pass
                self._actualizar_conteos()
                return

        # No estaba cargada — cargar desde el archivo
        uri = f"{ruta}|layername={nombre_capa}"
        layer = QgsVectorLayer(uri, nombre_capa, "ogr")
        if not layer.isValid():
            self._set_msg(f"No se pudo abrir {nombre_capa} en {ruta}.", error=True)
            return

        QgsProject.instance().addMapLayer(layer)
        self.capa_activa = layer
        self.iface.setActiveLayer(layer)
        self.iface.zoomToActiveLayer()
        layer.selectionChanged.connect(self._on_sel_cambiada)
        self._set_btns_tipo(True)
        self._actualizar_conteos()
        self._set_msg(f"Capa {nombre_capa} cargada.")

    # ------------------------------------------------------------------
    # Asignar tipo_geo
    # ------------------------------------------------------------------
    def asignar_tipo_geo(self, codigo_tipo):
        layer = self._capa_valida()
        if not layer:
            self._set_msg("Primero carga el recinto en el mapa.", error=True)
            return
        sel = layer.selectedFeatureIds()
        if not sel:
            self._set_msg("Selecciona puntos en el mapa primero.", error=True)
            return
        if not layer.isEditable():
            self.iface.actionToggleEditing().trigger()
        idx = layer.fields().indexOf(CAMPO_TIPO_GEO)
        if idx < 0:
            self._set_msg(f"Campo '{CAMPO_TIPO_GEO}' no encontrado.", error=True)
            return
        layer.beginEditCommand(f"tipo_geo_id={codigo_tipo}")
        for fid in sel:
            layer.changeAttributeValue(fid, idx, codigo_tipo)
        layer.endEditCommand()
        nombre = MAPA_TIPOS.get(codigo_tipo, str(codigo_tipo))
        self._set_msg(f"{len(sel)} punto(s) → {nombre}")
        self._actualizar_conteos()

    # ------------------------------------------------------------------
    # Conteos por tipo en los botones
    # ------------------------------------------------------------------
    def _actualizar_conteos(self):
        """Actualiza el texto de cada botón con el conteo actual de la capa."""
        layer = self._capa_valida()
        if not layer:
            for codigo, texto, _ in TIPOS_GEO:
                self._btns_tipo[codigo].setText(texto)
            return

        idx = layer.fields().indexOf(CAMPO_TIPO_GEO)
        if idx < 0:
            return

        conteos = {}
        total = 0
        revisados = 0
        for feat in layer.getFeatures():
            total += 1
            t = feat.attributes()[idx]
            try:
                t = int(t) if t is not None and str(t) not in ("", "NULL", "None") else None
            except (ValueError, TypeError):
                t = None
            if t is not None:
                conteos[t] = conteos.get(t, 0) + 1
                if t not in (8, 9):
                    revisados += 1

        # Actualizar botones
        for codigo, texto, _ in TIPOS_GEO:
            cnt = conteos.get(codigo, 0)
            btn = self._btns_tipo[codigo]
            if cnt > 0:
                btn.setText(f"{texto}  [{cnt}]")
            else:
                btn.setText(texto)

        # Actualizar barra
        pct = round(100 * revisados / total) if total else 0
        self._progress.setValue(pct)
        self._lbl_avance.setText(f"{revisados} / {total} rectificados ({pct}%)")

    # ------------------------------------------------------------------
    # Registrar avance y Entregar
    # ------------------------------------------------------------------
    def registrar_avance(self):
        if not self.asignacion or not self._conectado:
            return
        layer = self._capa_valida()
        if layer and layer.isEditable():
            layer.commitChanges()
        # Manifest: deja el archivo verificable para SIGEA del otro lado
        if layer and layer.source():
            ruta_src = layer.source().split("|")[0]
            _manifest_escribir(ruta_src, por=f"Plugin ({settings.usuario()})")
        n_rev = self._contar_revisados()
        try:
            api.registrar_avance(self.asignacion["id"], n_rev, settings.usuario())
            self.asignacion["avance"] = n_rev
            self._actualizar_vista()
            self._set_msg(f"Avance registrado: {n_rev} rectificados.")
        except api.SigeaError as e:
            self._set_msg(f"Error: {e}", error=True)

    def entregar(self):
        if not self.asignacion or not self._conectado:
            return
        layer = self._capa_valida()
        if layer and layer.isEditable():
            resp = QMessageBox.question(
                self, "Ediciones sin guardar",
                "Hay cambios sin guardar. ¿Guardar antes de entregar?",
                QMessageBox.Yes | QMessageBox.Cancel)
            if resp == QMessageBox.Cancel:
                return
            layer.commitChanges()

        # Manifest: SIGEA verificará el archivo antes de reimportar
        if layer and layer.source():
            ruta_src = layer.source().split("|")[0]
            _manifest_escribir(ruta_src, por=f"Plugin entrega ({settings.usuario()})")

        n_rev = self._contar_revisados()
        total = self.asignacion.get("n_electores", 0)
        pct = round(100 * n_rev / total) if total else 0

        dlg = _EntregaDialog(n_rev, total, pct, self)
        if dlg.exec_() != QDialog.Accepted:
            return

        try:
            api.entregar(self.asignacion["id"], settings.usuario(), dlg.observaciones())
            self._set_msg("✓ Recinto entregado.")
            if layer:
                QgsProject.instance().removeMapLayer(layer.id())
                self.capa_activa = None
            self.asignacion = None
            self._set_sin_asignacion()
        except api.SigeaError as e:
            self._set_msg(f"Error: {e}", error=True)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _capa_valida(self):
        """Devuelve SOLO la capa del recinto activo (R{codigo}). Nunca cae a
        la capa 'activa' arbitraria de QGIS: eso causaba conteos exagerados
        cuando el usuario seleccionaba otra capa (padrón, recintos, etc.)."""
        # 1) la referencia guardada, si sigue válida y es la correcta
        if (self.capa_activa and self.capa_activa.isValid() and
                self._es_capa_recinto(self.capa_activa)):
            return self.capa_activa
        # 2) buscar por nombre exacto entre las capas del proyecto
        if self._codigo_activo:
            objetivo = f"R{self._codigo_activo}"
            for layer in QgsProject.instance().mapLayers().values():
                if (isinstance(layer, QgsVectorLayer) and layer.isValid() and
                        layer.name() == objetivo):
                    self.capa_activa = layer
                    return layer
        return None

    def _es_capa_recinto(self, layer):
        try:
            return (self._codigo_activo is not None and
                    layer.name() == f"R{self._codigo_activo}")
        except Exception:
            return False

    def _contar_revisados(self):
        layer = self._capa_valida()
        if not layer:
            return 0
        idx = layer.fields().indexOf(CAMPO_TIPO_GEO)
        if idx < 0:
            return 0
        count = 0
        for feat in layer.getFeatures():
            t = feat.attributes()[idx]
            try:
                t = int(t) if t is not None and str(t) not in ("", "NULL", "None") else None
                if t is not None and t not in (8, 9):
                    count += 1
            except (ValueError, TypeError):
                pass
        return count

    def _refrescar_silencioso(self):
        self._actualizar_conteos()

    def _on_sel_cambiada(self, *args):
        layer = self._capa_valida()
        tiene = layer is not None and layer.selectedFeatureCount() > 0
        self._set_btns_tipo(tiene)

    def _set_btns_tipo(self, enabled):
        for btn in self._btns_tipo.values():
            btn.setEnabled(enabled and btn.isVisible())

    def _set_msg(self, txt, error=False):
        self._lbl_msg.setText(txt)
        c = "#c62828" if error else "#2e7d32"
        self._lbl_msg.setStyleSheet(f"font-size:10px;color:{c};margin-top:2px;")


# ------------------------------------------------------------------
# Diálogo de entrega
# ------------------------------------------------------------------
class _EntregaDialog(QDialog):
    def __init__(self, n_rev, total, pct, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Confirmar entrega")
        self.setMinimumWidth(300)
        lay = QVBoxLayout(self)
        color = "#2e7d32" if pct >= 90 else ("#ef6c00" if pct >= 50 else "#c62828")
        lay.addWidget(QLabel('<b style="font-size:13px">¿Entregar el recinto?</b>'))
        lay.addWidget(QLabel(
            f'<span style="color:{color};font-size:12px">'
            f'{n_rev} / {total} rectificados ({pct}%)</span>'))
        if pct < 100:
            av = QLabel(f"Quedarán {total - n_rev} puntos sin tipo geo.")
            av.setStyleSheet("color:#ef6c00;font-size:11px;")
            lay.addWidget(av)
        lay.addWidget(QLabel("Observaciones (opcional):"))
        self._obs = QTextEdit()
        self._obs.setFixedHeight(55)
        self._obs.setPlaceholderText("Nota para el supervisor...")
        lay.addWidget(self._obs)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("Entregar")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    def observaciones(self):
        return self._obs.toPlainText().strip()
